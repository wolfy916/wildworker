import * as React from "react";
import "./CoinHistory.css";

function CoinHistory(props) {
    return (
        <div className="modal-component">
            <div className="modal-title">코인 내역</div>
            <div className="modal-content">
                코인내역페이지에용
            </div>
        </div>
    );
};

export default CoinHistory;